from gym.envs.toy_text.blackjack import BlackjackEnv
from gym.envs.toy_text.roulette import RouletteEnv
from gym.envs.toy_text.frozen_lake import FrozenLakeEnv
from gym.envs.toy_text.nchain import NChainEnv
from gym.envs.toy_text.hotter_colder import HotterColder
from gym.envs.toy_text.guessing_game import GuessingGame
from gym.envs.toy_text.kellycoinflip import KellyCoinflipEnv
from gym.envs.toy_text.kellycoinflip import KellyCoinflipGeneralizedEnv
